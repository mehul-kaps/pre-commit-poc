package com.example.precommit.precommit_hook_poc;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class PrecommitHookPocApplication {

	public static void main(String[] args) {
		SpringApplication.run(PrecommitHookPocApplication.class, args);
	}

}
